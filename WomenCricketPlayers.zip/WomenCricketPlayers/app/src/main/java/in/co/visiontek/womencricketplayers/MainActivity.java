package in.co.visiontek.womencricketplayers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
RecyclerView recyclerView1;
ArrayList<Players> playersArrayList;
PlayersAdapter playersAdapter;
    String selctedRole,selctedPlayer;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView1=findViewById(R.id.recyclerView);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("CricketPlayers");
        loadData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.addBtn:
                Dialog dialog=new Dialog(this);
                dialog.setContentView(R.layout.add_player);
                Spinner spinnerPlayers=dialog.findViewById(R.id.spinnerPlayers);
                Spinner spinnerRole=dialog.findViewById(R.id.spinnerRole);
                ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(getApplicationContext(),R.array.team, android.R.layout.simple_spinner_dropdown_item) ;
                spinnerPlayers.setAdapter(arrayAdapter);
                ArrayAdapter<CharSequence> arrayAdapter1 = ArrayAdapter.createFromResource(getApplicationContext(),R.array.role, android.R.layout.simple_spinner_dropdown_item) ;
                spinnerRole.setAdapter(arrayAdapter1);
                dialog.show();
                Button addBTn=dialog.findViewById(R.id.AddDialogBtn);
                spinnerPlayers.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selctedPlayer=parent.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                spinnerRole.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selctedRole=parent.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            addBTn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addtoDatabase(selctedPlayer,selctedRole);
                    dialog.dismiss();
                    loadData();
                }
            });
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                playersArrayList=new ArrayList<>();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Players players=dataSnapshot.getValue(Players.class);
                    playersArrayList.add(players);
                }
                playersAdapter =new PlayersAdapter(getApplicationContext(),playersArrayList);
                recyclerView1.setAdapter(playersAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void addtoDatabase(String selctedPlayer, String selctedRole) {
        Players players=new Players(selctedPlayer,selctedRole);
        databaseReference.push().setValue(players);
    }

}