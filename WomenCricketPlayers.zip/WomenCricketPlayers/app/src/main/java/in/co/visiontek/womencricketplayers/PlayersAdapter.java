package in.co.visiontek.womencricketplayers;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PlayersAdapter extends RecyclerView.Adapter<PlayersAdapter.MyViewHolder> {
    Context context;
    ArrayList<Players> playersArrayList;
    DatabaseReference databaseReference;
    int currentPosition;
    public PlayersAdapter(Context context, ArrayList<Players> playersArrayList) {
        this.context = context;
        this.playersArrayList = playersArrayList;
    }

    @NonNull
    @Override
    public PlayersAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.player_list_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayersAdapter.MyViewHolder holder, int position) {
        Players players=playersArrayList.get(position);
        holder.playername.setText(players.getName());
        holder.playerrole.setText(players.getRole());
        if(players.getRole().equals("Batsman")) {
            holder.image.setImageResource(R.drawable.img);
        }
        if(players.getRole().equals("Bowler")) {
            holder.image.setImageResource(R.drawable.img_1);
        }
        if(players.getRole().equals("All Rounder")) {
            holder.image.setImageResource(R.drawable.img_2);
        }
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                PopupMenu popupMenu=new PopupMenu(context,v);
                currentPosition = holder.getAdapterPosition();
                popupMenu.getMenuInflater().inflate(R.menu.context_menu,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getItemId() == R.id.edit){
                            editPlayer();
                        }
                        else if (item.getItemId() == R.id.delete){
                            deletePlayer();
                        }

                        return true;
                    }
                });
                popupMenu.show();
                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(context,CricketerDetails.class);
                in.putExtra("Cricketer",players);
                v.getContext().startActivity(in);
            }
        });
    }

    private void deletePlayer() {
        Players players=playersArrayList.get(currentPosition);
        databaseReference= FirebaseDatabase.getInstance().getReference("CricketPlayers");
       Query query=databaseReference.orderByChild("name").equalTo(players.getName());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // remove the value at reference
                for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren()) {
                    dataSnapshot1.getRef().removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void editPlayer() {
        Dialog dialog=new Dialog(context);
        dialog.setContentView(R.layout.editplayer);
        dialog.show();
        EditText selectedPlayer=dialog.findViewById(R.id.selectedPlayerDialog);
        EditText selectedRole=dialog.findViewById(R.id.selectedPlayerDialog);
        Button updateBtn=dialog.findViewById(R.id.UpdateDialogBtn);
        Players players=playersArrayList.get(currentPosition);
        selectedPlayer.setText(players.getName());
        selectedRole.setText(players.getRole());
    /*    updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SelectedPlayer1=selectedPlayer.getText().toString();
                String SelectedRole1=selectedRole.getText().toString();
                databaseReference= FirebaseDatabase.getInstance().getReference("CricketPlayers");
                Query query=databaseReference.orderByChild("name").equalTo(players.getName());
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        // remove the value at reference
                        for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren()) {
                            Players players1=new Players(SelectedPlayer1,SelectedRole1);
                            dataSnapshot1.getRef().setValue(players1);
                            notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });*/
    }

    @Override
    public int getItemCount() {
        return playersArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView playername,playerrole;
                ImageView image;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            playername=itemView.findViewById(R.id.playerName);
            playerrole=itemView.findViewById(R.id.playerRole);
            image=itemView.findViewById(R.id.imageView);
        }
    }
}
