package in.co.visiontek.womencricketplayers;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class CricketerDetails extends AppCompatActivity {
TextView name,role;
ImageView imageView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cricketer_details);
        name=findViewById(R.id.playerName1);
        role=findViewById(R.id.playerRole1);
        imageView=findViewById(R.id.imageView1);
        Intent in= getIntent();
        Players players= (Players) in.getSerializableExtra("Cricketer");
        name.setText(players.getName());
        role.setText(players.getRole());
        if(players.getRole().equals("Batsman")) {
            imageView.setImageResource(R.drawable.img);
        }
        if(players.getRole().equals("Bowler")) {
            imageView.setImageResource(R.drawable.img_1);
        }
        if(players.getRole().equals("All Rounder")) {
            imageView.setImageResource(R.drawable.img_2);
        }
    }
}