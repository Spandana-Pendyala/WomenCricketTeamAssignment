package in.co.visiontek.womencricketplayers;

import java.io.Serializable;

public class Players implements Serializable {
    String name,Role;
    Integer image;

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }

    public Players(String name, String role, Integer image) {
        this.name = name;
        Role = role;
        this.image = image;
    }

    public Players() {
    }

    public Players(String name, String role) {
        this.name = name;
        Role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }
}
